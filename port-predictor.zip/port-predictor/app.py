from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load model & encoders
model = pickle.load(open("model.pkl", "rb"))
le_port, le_ship, le_weather, le_season = pickle.load(open("encoders.pkl", "rb"))

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Convert ALL inputs to float
        port = float(request.form['port'])
        ship = float(request.form['ship'])
        cargo = float(request.form['cargo'])
        ships = float(request.form['ships'])
        weather = float(request.form['weather'])
        berth = float(request.form['berth'])
        season = float(request.form['season'])

        # Prediction
        features = np.array([[port, ship, cargo, ships, weather, berth, season]])
        prediction = model.predict(features)

        return render_template('index.html',
                               prediction_text=f"⏳ Waiting Time: {round(prediction[0],2)} hours")

    except Exception as e:
        print("ERROR:", e)
        return render_template('index.html',
                               prediction_text=f"⚠️ Error: {e}")

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)